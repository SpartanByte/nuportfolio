﻿namespace GuessAWord
{
    partial class GuessAWord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordPlacementLabel = new System.Windows.Forms.Label();
            this.guessInstructionLabel = new System.Windows.Forms.Label();
            this.guessingInputBox = new System.Windows.Forms.TextBox();
            this.buttonSubmitGuess = new System.Windows.Forms.Button();
            this.guessResultLabel = new System.Windows.Forms.Label();
            this.hangmanLabel = new System.Windows.Forms.Label();
            this.buttonStartGuess = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wordPlacementLabel
            // 
            this.wordPlacementLabel.AutoSize = true;
            this.wordPlacementLabel.Font = new System.Drawing.Font("Letter Gothic Std", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordPlacementLabel.Location = new System.Drawing.Point(80, 182);
            this.wordPlacementLabel.Name = "wordPlacementLabel";
            this.wordPlacementLabel.Size = new System.Drawing.Size(176, 16);
            this.wordPlacementLabel.TabIndex = 0;
            this.wordPlacementLabel.Text = "The current word is: ";
            // 
            // guessInstructionLabel
            // 
            this.guessInstructionLabel.AutoSize = true;
            this.guessInstructionLabel.Font = new System.Drawing.Font("Letter Gothic Std", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guessInstructionLabel.Location = new System.Drawing.Point(88, 107);
            this.guessInstructionLabel.Name = "guessInstructionLabel";
            this.guessInstructionLabel.Size = new System.Drawing.Size(168, 16);
            this.guessInstructionLabel.TabIndex = 1;
            this.guessInstructionLabel.Text = "Guess a letter ---->";
            // 
            // guessingInputBox
            // 
            this.guessingInputBox.Font = new System.Drawing.Font("Letter Gothic Std", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guessingInputBox.Location = new System.Drawing.Point(289, 100);
            this.guessingInputBox.Name = "guessingInputBox";
            this.guessingInputBox.Size = new System.Drawing.Size(157, 23);
            this.guessingInputBox.TabIndex = 2;
            // 
            // buttonSubmitGuess
            // 
            this.buttonSubmitGuess.Font = new System.Drawing.Font("Letter Gothic Std", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSubmitGuess.Location = new System.Drawing.Point(290, 136);
            this.buttonSubmitGuess.Name = "buttonSubmitGuess";
            this.buttonSubmitGuess.Size = new System.Drawing.Size(156, 23);
            this.buttonSubmitGuess.TabIndex = 3;
            this.buttonSubmitGuess.Text = "Submit My Guess!";
            this.buttonSubmitGuess.UseVisualStyleBackColor = true;
            this.buttonSubmitGuess.Click += new System.EventHandler(this.buttonSubmitGuess_Click);
            // 
            // guessResultLabel
            // 
            this.guessResultLabel.AutoSize = true;
            this.guessResultLabel.Font = new System.Drawing.Font("Letter Gothic Std", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guessResultLabel.Location = new System.Drawing.Point(80, 310);
            this.guessResultLabel.Name = "guessResultLabel";
            this.guessResultLabel.Size = new System.Drawing.Size(427, 15);
            this.guessResultLabel.TabIndex = 4;
            this.guessResultLabel.Text = "This is placement text for the Label named guessResultLabel ";
            // 
            // hangmanLabel
            // 
            this.hangmanLabel.AutoSize = true;
            this.hangmanLabel.Font = new System.Drawing.Font("Letter Gothic Std", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hangmanLabel.Location = new System.Drawing.Point(286, 182);
            this.hangmanLabel.Name = "hangmanLabel";
            this.hangmanLabel.Size = new System.Drawing.Size(192, 16);
            this.hangmanLabel.TabIndex = 5;
            this.hangmanLabel.Text = "Placeholder Mr. Hangman";
            this.hangmanLabel.Click += new System.EventHandler(this.hangmanLabel_Click);
            // 
            // buttonStartGuess
            // 
            this.buttonStartGuess.Font = new System.Drawing.Font("Letter Gothic Std", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStartGuess.Location = new System.Drawing.Point(198, 12);
            this.buttonStartGuess.Name = "buttonStartGuess";
            this.buttonStartGuess.Size = new System.Drawing.Size(186, 23);
            this.buttonStartGuess.TabIndex = 6;
            this.buttonStartGuess.Text = "I Want To Play! (Start)";
            this.buttonStartGuess.UseVisualStyleBackColor = true;
            this.buttonStartGuess.Click += new System.EventHandler(this.buttonStartGuess_Click);
            // 
            // GuessAWord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(623, 467);
            this.Controls.Add(this.buttonStartGuess);
            this.Controls.Add(this.hangmanLabel);
            this.Controls.Add(this.guessResultLabel);
            this.Controls.Add(this.buttonSubmitGuess);
            this.Controls.Add(this.guessingInputBox);
            this.Controls.Add(this.guessInstructionLabel);
            this.Controls.Add(this.wordPlacementLabel);
            this.Name = "GuessAWord";
            this.Text = "GuessAWord!";
            this.Load += new System.EventHandler(this.GuessAWord_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wordPlacementLabel;
        private System.Windows.Forms.Label guessInstructionLabel;
        private System.Windows.Forms.TextBox guessingInputBox;
        private System.Windows.Forms.Button buttonSubmitGuess;
        private System.Windows.Forms.Label guessResultLabel;
        private System.Windows.Forms.Label hangmanLabel;
        private System.Windows.Forms.Button buttonStartGuess;
    }
}

