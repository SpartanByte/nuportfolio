﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuessAWord
{
    public partial class GuessAWord : Form
    {


        // Declaring string/array variables
        string randomWord;
        string[] words;


        //Random number generator 
        int randomNumber;
        Random randomNumberGenerator;

        // Declaring any constants that are needed
        const int MAXWORDS = 10;
        const int MAX_ATTEMPTS = 3;
        int attempts = MAX_ATTEMPTS;

        public GuessAWord()
        {

            // Values for words[] array
            words = new string[MAXWORDS];
            randomNumberGenerator = new Random();
            words[0] = "george";
            words[1] = "igor";
            words[2] = "chuck";
            words[3] = "nate";
            words[4] = "jill";
            words[5] = "betty";
            words[6] = "edna";
            words[7] = "debby";
            words[8] = "jerry";
            words[9] = "jamal";

            // Initializing Component
            InitializeComponent();
        }

        private void GuessAWord_Load(object sender, EventArgs e)
        {

        }

        private void buttonStartGuess_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Here we go!");
            randomNumber = randomNumberGenerator.Next(0, MAXWORDS - 1);
            randomWord = words[randomNumber];

            hangmanLabel.Text = "";
            attempts = MAX_ATTEMPTS;

            for (int i = 0; i < randomWord.Length; i++) 
            {
                hangmanLabel.Text += "*";
            }

            guessResultLabel.Text = "";
            buttonSubmitGuess.Enabled = true;
            guessingInputBox.Select();
        }

        private void buttonSubmitGuess_Click(object sender, EventArgs e)
        {
            if (attempts < 0)
            {
                MessageBox.Show("The game is lost!");
            }

            else
            {
                // counts length of each array value
                int shortestWordLength = 0;

                randomNumber = randomNumberGenerator.Next(0, MAXWORDS - 1);
                randomWord = words[randomNumber];

                if (randomWord.Length < guessingInputBox.Text.Length)
                {
                    shortestWordLength = randomWord.Length;
                }
                else
                {
                    // Catches word that is shortest from user input textbox
                    shortestWordLength = guessingInputBox.Text.Length;
                }
                // Working through the array after finding shortest value via .Length
                for (int i = 0; i < shortestWordLength; i++)
                
                        // Conditional for each iteration
                        if (randomWord[i] == guessingInputBox.Text[i])
                        {
                        char[] letters = hangmanLabel.Text.ToCharArray();
                            letters[i] = randomWord[i];
                            // converting char back to string
                            hangmanLabel.Text = letters.ToString();
                        }
                }
            // counting down attempts
                attempts--;
            if (attempts == 0)
            {
                MessageBox.Show("You Lose :-( but try again!");
            }
        }

        private void hangmanLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
