<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Http\FormRequest;
use App\Models\Domain;
use App\Models\Scan;
use App\User;
use App\Services\SSL\SingleScanService;
use App\Services\SSL\LastReportService;
use App\Services\Domains\DomainsTableService;
use Auth;
use Carbon\Carbon;

class AdminController extends Controller
{
    // Creates a new auth controller instance
    public function __construct()
    {
    	$this->middleware('auth');
    }

	public function home()
	{
        $id = Auth::user()->id;
        $profile = User::findOrFail($id);

        $loadDomains = new DomainsTableService;
        $domainsArray = $loadDomains->getDomains();

        $getReport = new LastReportService;
        $reportDate = $getReport->getLastReport();

        return view('admin.home')->with(compact('domainsArray', 'profile', 'reportDate'));
	}

	public function show($id)
	{
        // showing individual domain details
        $domain = Domain::findOrFail($id)->with('contacts')->first();
        $user = Auth::user()->id;
        $createdFormatted = Carbon::parse($domain->created_at)->format("Y-m-d");

        return view('admin.show')->with(compact('domain', 'user', 'createdFormatted'));
	}

	public function create()
	{
        // adding a new domain
        return view('admin.create');
	}

	 public function store(Request $request, SingleScanService $scanData)
	{
		// Validate input first
		$this->validate($request, [
			'domain' => 'required',
			'port' => 'required',
			'client' => 'required'
		]);

		$newDomain = new DomainsTableService;
		$response = $newDomain->addDomain($request, $scanData);

        if($response['errors'] == true){
            return view('errors.error-messages')->with(compact('response'));
        }

        return redirect()->route('admin.home');
    }

    public function edit($id)
    {
        $user = Auth::user()->id;
        // updating the post with the edit form
        $domain = Domain::find($id);
        return view('admin.edit')->with(compact('domain', 'user'));
    }

    public function update(Request $request, $id)
    {
        // Updating domain via DomansTableService updateDomain()
        $update = new DomainsTableService;
        $updateConfirm = $update->updateDomain($request, $id);
        return redirect()->route('admin.home');
    }

    public function destroy($id)
    {
    	// removing domain from database
    	$domain = Domain::findOrFail($id);
    	$domain->delete();
    	// redirect to admin homepage
    	return redirect()->route('admin.home');
    }
}