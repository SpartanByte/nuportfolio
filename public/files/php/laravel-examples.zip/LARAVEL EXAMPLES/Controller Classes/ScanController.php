<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;
use App\Services\SSL\SavedDataService;
use App\Services\SSL\AllScansService;
use App\Services\Users\UserViewsService;
use App\Models\Domain;
use App\Models\Contact;
use App\Models\Scan;
use App\User;
use Auth;
use Exception;
use App\Jobs\CustomCollection;

class ScanController extends Controller
{
    // Displays all domains
    public function index()
    {
        $id = Auth::user()->id;
        $profile = User::findOrFail($id);
        $domains = Domain::all();

        return view('scans.index')->with(compact('domains', 'profile'));
    }

    // shows all scans for a selected domain
    public function viewAll($id, AllScansService $allData)
    {
        $domain = Domain::findOrFail($id);
        $setScans = new AllScansService;
        $scans = $setScans->getDomainScans($id);

        return view('scans.view-all')->with(compact('scans', 'domain'));
    }

     public function showMyScans($id)
    {
        $user  = Auth::user()->where('id', $id)->first();
        $pullMyData = new UserViewsService;
        $domains = $pullMyData->getContactDomains($user);
        $myDomains = $pullMyData->getMyDomains();
        $myScans = $pullMyData->getMyScans($id);
        return view ('scans.showmyscans')->with(compact('user', 'myScans', 'myDomains', 'domains', 'profile'));
    }

    public function viewRawData($id)
    {
        $pullRawData = new UserViewsService;
        $rawArray = $pullRawData->getRawData($id);
        return view('scans.raw-data')->with(compact('rawArray'));
    }

    public function destroy($id)
    {
        $scan = Scan::findOrFail($id);
        $scan->delete();
        return redirect()->route('scans.index');
    }

}