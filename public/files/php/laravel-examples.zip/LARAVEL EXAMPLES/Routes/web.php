<?php
// GENERAL PAGE ROUTES
Route::get('/', 'PageController@home');
Route::get('/home', 'PageController@home');
Route::post('/logout', 'LoginController@logout')->name('logout');
Route::get('/password/reset', function(){
	return view('/password/reset/{token}')->name('password.reset');
});

/** ======= Admin\Domains Management Routes ======= */
Auth::routes();
Route::resource('admin', 'AdminController');
Route::get('/admin', 'AdminController@home')->name('admin.home');
Route::prefix('admin')->name('admin.')->group(function(){
	// Create/Store Domains:
	Route::get('create', 'AdminController@create')->name('create');
	Route::post('/', 'AdminController@store')->name('store');
	// Edit/Update Domains:
	Route::get('{domain}/edit', 'AdminController@edit')->name('edit');
	Route::post('{id}', 'AdminController@update')->name('update');
	// Delete Domains:
	Route::get('{id}/delete', 'AdminController@destroy')->name('delete');
});

/** ======= Domain Profile Routes ======= */
Route::resource('profile', 'ProfileController');
Route::group(['middleware' => ['auth']], function(){
	Route::prefix('profile')->name('profile.')->group(function(){
		//Index of Domains and Contacts
		Route::get('/', 'ProfileController@index')->name('index');
		Route::get('showmydomains/{id}', 'ProfileController@showMyDomains')->name('showmydomains');
		//Create/Store Profile
		Route::get('create', 'ProfileController@create')->name('create');
		Route::post('store', 'ProfileController@store')->name('store');
		// Edit/Update Profile
		Route::get('{profile}/edit', 'ProfileController@edit')->name('edit');
		Route::post('{profile}', 'ProfileController@update')->name('update');

		// Delete
		Route::get('{profile}/delete', 'ProfileController@destroy')->name('delete');
		Route::get('response', 'ProfileController@store')->name('response');
	});
});

Route::group(['middleware' => ['auth']], function(){
	/** ======= Scans Routes ======= */
	Route::prefix('scans')->name('scans.')->group(function(){
		Route::get('/', 'ScanController@index')->name('index');
		Route::get('showmyscans/{id}', 'ScanController@showMyScans')->name('showmyscans');
		Route::get('{id}/raw-data', 'ScanController@viewRawData')->name('raw-data');
		Route::get('{profile}/view-all', 'ScanController@viewAll')->name('view-all');
		Route::get('{scan}/delete', 'ScanController@destroy')->name('delete');
	});

	Route::get('{profile}/view-all', 'ScanController@viewAll')->name('view-all');

	/** ======= Email Preview Routes ======= */
	Route::get('emails/reminder', 'PageController@previewReminder');
	Route::get('emails/expired', 'PageController@previewExpired');
    Route::get('emails/user-created', 'PageControler@userCreated');

	/** ======= Error Handling Routes ======= */
	Route::prefix('errors')->name('errors.')->group(function(){
		Route::get('error-messages', 'ProfileController@store')->name('error-messages');
		Route::get('domain-exists', 'AdminController@store')->name('domain-exists');
	});
});

Route::group(['middleware' => ['auth']], function(){
	/** ======= User Management Routes ======= */
	Route::prefix('users')->name('users.')->group(function(){
		Route::get('show-all', 'UserManagementController@index')->name('index');
		Route::get('add-success', 'UserManagementController@storeUser')->name('add-success');
		// create/store
		Route::get('create', 'UserManagementController@createUser')->name('create');
		Route::post('store', 'UserManagementController@storeUser')->name('store');
        // edit/update
		Route::get('{id}/edit', 'UserManagementController@editUser')->name('edit');
        Route::post('{id}', 'UserManagementController@updateUser')->name('update');
	});
});