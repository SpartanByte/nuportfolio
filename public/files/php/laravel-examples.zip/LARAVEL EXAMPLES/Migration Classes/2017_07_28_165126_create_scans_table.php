<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateScansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // create the table
        Schema::create('scans', function(Blueprint $table){
            $table->increments('id');
            $table->integer('domain_id');
            $table->text('domain');
            $table->text('status')
                ->nullable();
            $table->text('scan_date')
                ->nullable();
            $table->text('scan_details')
                ->nullable();
            $table->text('raw');
            $table->integer('error_code');
            $table->string('issuer')
                ->nullable()
                ->default(null);
            $table->dateTime('start')
                ->nullable()
                ->default(null);
            $table->dateTime('expire')
                ->nullable()
                ->default(null);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // drop the table
        Schema::dropIfExists('scans');
    }
}
