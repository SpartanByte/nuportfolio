@extends('layouts.default')
@section('content')
    <div class="grey-banner">
        <div class="description-container">
            <h3 class="text-h1 text-up">All Domains</h3>
            <p>The following domains have been added to The Backchecker for checking SSL certificate validity and retrieving expiration dates for monitoring and email notifications to domain contacts. Each has been submitted by adding the domain, which automatically runs at full SSL certificate check at that moment. The system automatically assumes the 'https' HTTP verb and inserts the colon before the port number (<em>i.e. "https://greatinsight.com:443"</em>). When adding a domain, only 'greatinsight.com' and '443' are needed.</p>

            <p>After a domain is added, certificate checks are run daily at 4am CST. These checks are run on all domains and are logged in the database including the raw data from the response to the check. Notifications are sent domain contacts if a certificate is expiring within thirty days, is already expired, or if there is an error in the scan suggesting an SSL certificate does not exist for that domain.</p>

            <p style="text-align:center;">
                <a href="{{ route('admin.create') }}">Adding A Domain</a>
                <a href="{{ route('profile.index') }}">Adding A Domain Profile</a>
            </p>
            @if(empty($reportDate))
                <div class="nothing-found">
                    <p><span class="red-warning">There are no reports to display yet.</span></p>
                </div>
            @else
                <p style="text-align:center;"><span class="text-h3 highlight-box">Last Report Generated: {{$reportDate}} CST </span></p>
            @endif
        </div>
    </div>
    @if(count($domainsArray) == 0)
        <div class="descriptions-container">
            <div class="nothing-found">
                <p><span class="emoji">&#9785;</span></p>
                <p><span class="red-warning">There are no domains in the database.</span></p>
                <div class="form-btn-wrapper">
                    <p><a href="{{ route('admin.create') }}">Add a Domain</a></p>
                </div>
            </div>
        </div>
    @else
        <div class="table-container">
            <table class="cert-table" style="width:100%;">
                <thead class="cert-head">
                    <th>Domain (Hostname)</th>
                    <th>ID</th>
                    <th>Port</th>
                    <th>Client</th>
                    <th>Certificate Issuer</th>
                    <th>Date Issued</th>
                    <th>Expiration Date</th>
                    <th>Status</th>
                    <th class="btn-header text-center">Edit</th>
                    <th class="btn-header text-center">View</th>
                    <th class="btn-header text-center">View Scans</th>
                    <th class="btn-header text-center">Delete</th>
                </thead>
                <tbody>
                   @foreach($domainsArray as $domain)
                    <tr>
                        <td>{{$domain->domain}}</td>
                        <td>{{$domain->id}}</td>
                        <td>{{$domain->port}}</td>
                        <td>{{$domain->client}}</td>
                        <td>{{$domain->issuer}}</td>
                        @if($domain->date_issued == null)
                            <td>Not Available</td>
                        @else
                            <td>{{$domain->date_issued}}</td>
                        @endif
                        @if($domain->expire_date == null)
                            <td>Not Available</td>
                        @else
                            <td>{{$domain->expire_date}}</td>
                        @endif
                        <td>{{$domain->last_status}}</td>
                        <td><a class="btn-standard edit-btn" href="admin/{{$domain->id}}/edit">Edit Domain</a></td>
                        <td><a class="btn-standard view-btn" href="admin/{{$domain->id}}">View Details</a></td>
                        <td><a class="btn-standard edit-btn" href="scans/{{$domain->id}}/view-all">View Scans</a></td>
                        <td>
                            <form class="delete-form delete" method="DELETE" action="{{ route('admin.delete', $domain->id) }}">
                                <div class="btn-standard delete-btn">
                                    <button type="button" class="btn-standard delete-btn" data-toggle="modal" data-target="#confirmationModal">
                                        Delete Domain
                                    </button>
                                    <div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                        <div class="modal-dialog" style="color:#000;" role="document">
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                    <h5 class="modal-title text-h3 red-text" id="modalLabel">Confirmation</h5>
                                                    <p>Are you sure you want to delete this item?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary cancel-modal"
                                                        data-dismiss="modal">Cancel</button>
                                                    <button class="btn red-warning modal-btn" style="background:#E60000;color:#fff;"
                                                        formaction="{{ route('admin.delete', $domain->id) }}">Yes</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    <script src="{{ URL::asset('js/general.js') }}" /></script>
@stop