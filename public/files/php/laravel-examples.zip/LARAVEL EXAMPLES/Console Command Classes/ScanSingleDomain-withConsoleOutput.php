<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\Domain;
use Services\SSL\CertCheckerService;
use App\Services\SSL\SingleScanService;

class ScanSingleDomain extends Command
{
    // name and description
    protected $signature = 'domain:scan';
    protected $description = 'scan a single domain for a valid ssl certificate';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $domain = $this->ask('What domain and port would you like to scan?');
        $response = [];

        // open a new curl instance and set options
        $curl = curl_init($domain);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_NOBODY, true);
        curl_setopt($curl, CURLOPT_CERTINFO, true);
        curl_setopt($curl, CURLOPT_VERBOSE, 1);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
        curl_exec($curl);

        $certInfo = curl_getinfo($curl, CURLINFO_CERTINFO);
        $output = curl_error($curl);
        $errorCode = curl_errno($curl);

        // $this->info("<fg=blue;>The following information is $certInfo</>" . ":<fg=red;>".$certInfo[0]."</>");
        var_dump($certInfo);

        if(curl_errno($curl)){
            // error codes, error text returned to "last_status" in database
             $this->info("<fg=red;options=underscore>Request Error: </>".curl_errno($curl));

             if(curl_errno($curl) == 51){
                $errorCode = curl_errno($curl);
                $this->info($errorCode);
            }
            if(curl_errno($curl) == 28){
                $this->info("The output is below: ");
                $this->info($output);
                $this->info("<fg=blue;>Connection Timed Out!</>");
            }
            if(curl_errno($curl) == 60){
                $this->info("<fg=blue;>Peer certificate cannot be authenticated with known CA certificates.");
            }

            if(curl_errno($curl) == 7 || 28){
                $this->info("<fg=blue;>Connection Timed Out!</>");
            } // End of error codes
        }else{
            // successful, returning cert info data
            $certSerial = $certInfo[0]['Serial Number'];
            $certDateIssued = $certInfo[0]['Start date'];
            $certExpiration = $certInfo[0]['Expire date'];
            $certIssuer = $certInfo[0]['Expire date'];
            $certRaw = $certInfo[0]['Cert'];
            $collectAll = $certInfo;

            // outputting data for testing/development purposes
            $this->info('The following is the SSL Certificate serial number' . "\n" . '<fg=blue;>' . $certSerial . '</>');

            $response = [
                'domain' => $domain,
                'certDateIssued' => $certDateIssued,
                'certExpiration' => $certExpiration,
                'certRaw' => $certRaw,
            ];

            $this->info("<fg=red;options=underscore>Results To The Following Domain: </>");
            $this->info("Domain Name: <fg=blue;>" .  $response['domain'] .  "</>");
            $this->info("Date Issued:  <fg=blue;>" .   $response['certDateIssued'] . "</>");
            $this->info("Expiration Date:  <fg=blue;>" . $response['certExpiration'] . "</>");
            $this->info("SSL Certificate:  <fg=blue;>" . $response['certRaw'] . "</>");
            $errorCode = curl_errno($curl);
            $this->info($errorCode);
        }
    }
}