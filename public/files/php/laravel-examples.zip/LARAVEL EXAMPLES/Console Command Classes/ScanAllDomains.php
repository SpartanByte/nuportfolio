<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Console;
use App\Models\Domain;
use App\Models\Scan;
use App\Services\SSL\CertCheckerService;
use App\Services\SSL\RunScanService;
use DB;
use Carbon\Carbon;

class ScanAllDomains extends Command
{

    /**
     * Command Name
     * @var string
     */
            protected $signature = 'domain:all';
    /**
     * Command Description
     * @var string
     */
    protected $description = 'scan all domains for valid SSL certificate';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        // new instance from RunScanService, checks all domains for valid SSL Certificates
        // saves raw data, domain_id, issuer, start and expiration dates into Scans table
        RunScanService::runScan();
    }
}