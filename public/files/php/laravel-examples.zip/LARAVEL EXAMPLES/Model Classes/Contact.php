<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Contact extends Model
{
    // This needs to be inside the Model class, not outside/at the top
    use SoftDeletes;
    // setting the table to notifications (for notifications and profiles)
    protected $table = 'contacts';

    protected $fillable = [
    	'contact_id',
        'name',
        'email',
        'domain',
        'domain_id',
        'reminders_on',
        'expirations_on'
    ];

    public function profile(){
    	return $this->hasMany('App\User');
    }

    public function userDomains(){
        return $this->belongsTo('App\Models\Domain', 'domain', 'domain');
    }

    // to match a single contact to their domains
    public function myDomains(){
        return $this->hasOne('App\Models\Domain', 'domain', 'domain');
    }
}
