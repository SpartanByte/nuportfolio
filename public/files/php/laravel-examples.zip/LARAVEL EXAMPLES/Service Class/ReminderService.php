<?php
namespace App\Services\Emails;

use Illuminate\Support\Facades;
use Carbon\Carbon;
use App\Models\Domain;
use App\Models\Scan;
use App\Models\Contact;
use Artisan;
use Mail;
use DB;

class ReminderService{
	// called by email:reminder artisan command
	public static function createReminder(){
		// for each domain, scan for expiration, send reminder to domain contact
		$emailData = [];
		$checkArray = [];
		// Get today's date then add 30 days
		$nextMonth = new Carbon;
		$nextMonth = $nextMonth->addDays(30);
		$domains = Contact::all();

		// building array of domains
		foreach($domains as $domain){
			$check = $domain->domain;
			array_push($checkArray, $check);
        }

		foreach($checkArray as $domain){
			$domainTable = Domain::where('domain', $domain)->first();
			$contact = Contact::where('domain', $domain)->first();

			$expire = $domainTable->expire_date;
			if($expire == null){
				$catch = new Carbon();
				$expire = $catch;

			} else{
				$expire = date("Y-m-d", strtotime($expire));
			}

			$email = $contact->email;
			$name = $contact->name;
			$emailData = array(
				'domain' => $domain,
				'name' => $name,
				'email' => $email,
				'expire' => $expire,
			);
			$data = $emailData;
			// only send a mail reminder if expiration date is less than 30 days

			if($expire > $nextMonth){

				Mail::send('emails.reminder', ['data' => $data], function($message) use($data){
	            	$contact_email = $data['email'];
	            	$message->from('bwardwell@greatinsight.com', 'Insight Technologies');
	            	$message->to($contact_email);
	            	$message->subject("SSL Certificate Reminder: Approaching Expiration Date");
        		});
                // Command Line Confirmation that a message was sent
        		echo "Message sent successfully to " . $data['email'] . " for domain: ". $data['domain'] . "\r\n";
        	} else{
        		// command line feedback that a message was not sent
        		echo "A message was not sent" . "\r\n";
        	}
        }
	}
}
