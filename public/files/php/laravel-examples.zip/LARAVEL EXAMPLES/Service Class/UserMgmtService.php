<?php
namespace App\Services\Users;

use Illuminate\Support\Facades;
use App\Models\Domain;
use App\Models\Contact;
use App\User;
use Carbon\Carbon;
use Mail;

class UserMgmtService{

	public function addUser($request){

        $user = User::create([
            'name' => ucwords($request->name),
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);
        $added = User::where('email', $request->email)->first();

        $userInfo = [
            'name' => ucwords($request->name),
            'email' => $request->email,
            'id' => $added->id
        ];

        $data = $userInfo;
        Mail::send('emails.user-created', ['data' => $data], function($message) use($data){
            $userEmail = $data['email'];
            $message->from('bwardwell@greatinsight.com', 'Insight Technologies');
            $message->to($userEmail);
            $message->subject("An Account Was Created For You");
        });

        return $userInfo;

	}

	public function addUserProfile($request){
        // Getting user
        $userEmail = $request->email;

        $getUser = User::where('email', $userEmail)->first();
        $userId = $getUser->id;

        $domainExists = true;
        $profileExists = false;
        $userExists = true;

        $profileCheck = Contact::where('contact_id', $userId)->get(); // finding user ID
        $domainsTable = Domain::where('domain', $request->domain)->first();

        // making sure the domain being added will match a domain in the domains table, error if it doesn't exist
        if($domainsTable == null){
            $domainExists = false;
            return view('profile.create')->with(compact('domainExists'));
        }

        $domainCheck = Domain::where('domain', $domainsTable->domain)->first(); // finding Domain, domain_contacts table
        $domainValue = $domainCheck->domain;

        // Getting input data
        $reminders = $request->reminders;
        $expirations = $request->expirations;
        $url = $request->domain;

        // setting email notification options
		if($reminders == null){
		    $reminders = 0;
		} else{
		    $reminders = 1;}

		if($expirations == null){
	        $expirations = 0;
		} else{
	        $expirations = 1;}

		// removing https:// if it was entered
		if(substr($url, 0, 8) === "https://"){
		    $url = substr($url, 8);
		}
		// making sure there is not a trailing forward slash
		if(substr($url, -1) === "/"){
		    $url = substr($url, 0, -1);
		}

		$contact = Contact::create([
	        'contact_id' => $userId,
	        'name' => ucwords($request->name),
	        'email' => $request->email,
	        'domain' => $request->domain,
	        'reminders_on' => $reminders,
	        'expirations_on' => $expirations,
		]);
	}

	public function updateUserInfo($request, $id){

        $user = User::find($id);

        $user->name = $request->name;
        $user->email = $request->email;
        $user->save();
	}
}