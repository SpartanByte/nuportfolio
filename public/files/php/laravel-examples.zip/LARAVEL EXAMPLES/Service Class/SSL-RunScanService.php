<?php
namespace App\Services\SSL;

use Illuminate\Support\Facades;
use Carbon\Carbon;
use App\Models\Domain;
use App\Models\Scan;
use Illuminate\Support\Facades\DB;
use Artisan;

class RunScanService{
	// called by domain:all artisan command
	public static function runScan(){
		// Getting domain URLs from Database
		$domains = Domain::all();
		$allScans = [];
        foreach($domains as $domain){
            // getting cert info for each domain as domain domain
            $curl = curl_init('https://'.$domain->domain.":".$domain->port);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_NOBODY, true);
            curl_setopt($curl, CURLOPT_CERTINFO, true);
            curl_setopt($curl, CURLOPT_VERBOSE, 1);
            curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
            curl_exec($curl);
            // requesting ssl certificate info
            $certInfo = curl_getinfo($curl, CURLINFO_CERTINFO);
            $output = curl_error($curl);
            $errorCode = curl_errno($curl);
            $scan = new Scan;
            date_default_timezone_set("America/Chicago");
            $reportDate = date("m/d/Y g:ia");
            $issuerUnknown = "Unknown Issuer"; // setting one variable for all unknowns

            // this prevents the curl requests service from stopping if reaching an "Unidentified Offset: 0" error
            if($certInfo == null){

                if($errorCode == 60){
                    $statusDetails = "SSL certificate problem: self signed certificate, cannot be authenticated with known CA certificates";
                    $raw = json_encode($statusDetails);
                    $scan->status = "Unable to Authenticate";
                    $scan->scan_details = $statusDetails;

                }elseif($errorCode == 7){
                    $raw = json_encode("Failed to connect to " . $domain->domain . "on port" . $domain->port . " Connection Refused");
                    $status = "Failed to connect/refused";
                    $scan->status = $status;

                }elseif($errorCode == 28){
                    $statusDetails = "Connection timed out after 5001 milliseconds";
                    $raw = json_encode($certInfo);
                    $scan->status = "Connection Timed Out";
                }elseif($errorCode == 51){
                    $status = "No SSL certificate matches the domain name";
                    $statusDetails = "No SSL certificate matches the domain name";
                    $raw = json_encode($certInfo);
                }else{
                    $raw = "ERROR! No curl connection could be made. File not found on TFTP server. Ensure the domain is correct and the full given url is using the 'https' HTTP verb rather than 'http'. ";
                    $shortMessage = "No curl connection could be established, SSL certificate not found";
                    $errorCode = 999;
                    $scan->status = "No SSL Found";
                    $scan->scan_details = $shortMessage;
                }

                $scan->domain = $domain->domain;
                $scan->domain_id = $domain->id;
                $scan->issuer = $issuerUnknown;
                $scan->error_code = $errorCode;
                $scan->raw = $raw;
                $scan->start = null;
                $scan->expire = null;
                $scan->scan_date = $reportDate;
                $scan->save();

                $domain->last_status = $scan->status;
                $domain->expire_date = $scan->expire;
                $domain->issuer = $scan->issuer;
                $domain->date_issued = $scan->start;
                $domain->scan_date = $reportDate;
                $domain->save();

            }else{
                // SUCCESS!!
                $certificate = $certInfo[0];
                $certIssuer = $certificate['Issuer'];
                preg_match('/O = (.*?), [a-z]+ =/i', $certIssuer, $issuerMatches); // Get the certificate issuer
                $certIssuer = $issuerMatches[1];
                $certDateIssued = $certInfo[0]['Start date'];
                $certExpiration = $certInfo[0]['Expire date'];
                $statusDetails = "SSL certificate check was successful";
                $raw = json_encode($certInfo[0]);

                // Formatting
                $certDateIssued = date("Y-m-d", strtotime($certDateIssued));
                $certExpiration = date("Y-m-d", strtotime($certExpiration));

                if($certDateIssued > $reportDate){
            		$status = "Valid";
                } else {
            		$status = "Status Error";
                }

                $scan->raw = $raw;
                $scan->scan_details = $statusDetails;
                $scan->issuer = $certIssuer;
                $scan->error_code = $errorCode;
                $scan->status = $status;
                $scan->start = $certDateIssued;
                $scan->expire = $certExpiration;
                $scan->domain_id = $domain->id;
                $scan->domain = $domain->domain;
                $scan->scan_date = $reportDate;
                $scan->save();

                $domain->last_status = $scan->status;
                $domain->expire_date = $certExpiration;
                $domain->issuer = $certIssuer;
                $domain->date_issued = $certDateIssued;
                $domain->scan_date = $reportDate;
                $domain->save();
        	}
        }
    }
}